"""
Core 클래스
모든 매니저 클래스를 초기화하고 관리하는 중앙 관리 클래스입니다.
"""

import sys
from typing import Dict, Any, Optional

from .singleton import Singleton
from ..log.logger import Logger
from ..gui.main_form import MainForm


class Core(Singleton):
    """
    애플리케이션의 핵심 관리 클래스
    모든 매니저 클래스를 초기화하고 관리합니다.
    """
    
    def _initialize(self):
        """Core 초기화"""
        self._logger = Logger.get_instance()
        self._managers: Dict[str, Any] = {}
        self._main_form: Optional[MainForm] = None
        self._initialized = False
        
        self._logger.info("Core 클래스 초기화 시작")
    
    def initialize_application(self):
        """애플리케이션 전체 초기화"""
        try:
            self._logger.info("애플리케이션 초기화 시작")
            
            # 1. 로그 시스템 초기화 확인
            self._ensure_logger_initialized()
            
            # 2. GUI 초기화
            self._initialize_gui()
            
            # 3. 매니저 클래스들 초기화
            self._initialize_managers()
            
            # 4. 초기화 완료 표시
            self._initialized = True
            self._logger.info("애플리케이션 초기화 완료")
            
        except Exception as e:
            self._logger.exception(f"애플리케이션 초기화 실패: {e}")
            self._show_error_and_exit("초기화 오류", f"애플리케이션 초기화 중 오류가 발생했습니다:\n{e}")
    
    def _ensure_logger_initialized(self):
        """로거 초기화 확인"""
        if not self._logger:
            self._logger = Logger.get_instance()
        self._logger.info("로거 시스템 확인 완료")
    
    def _initialize_gui(self):
        """GUI 초기화"""
        try:
            self._main_form = MainForm.get_instance()
            self._logger.info("GUI 초기화 완료")
        except Exception as e:
            self._logger.exception(f"GUI 초기화 실패: {e}")
            raise
    
    def _initialize_managers(self):
        """매니저 클래스들 초기화"""
        try:
            # 설정 매니저 초기화
            from ..utils import ConfigManager
            config_manager = ConfigManager.get_instance()
            self.add_manager("config", config_manager)
            
            # 향후 추가될 매니저 클래스들을 여기서 초기화
            # 예: 데이터 매니저, AI 매니저 등
            
            self._logger.info("매니저 클래스 초기화 완료")
            
        except Exception as e:
            self._logger.exception(f"매니저 클래스 초기화 실패: {e}")
            raise
    
    def _show_error_and_exit(self, title: str, message: str):
        """오류 메시지 표시 후 종료"""
        try:
            if self._main_form:
                self._main_form.show_message(title, message, "error")
            else:
                print(f"오류: {title} - {message}")
        except:
            print(f"오류: {title} - {message}")
        finally:
            sys.exit(1)
    
    def get_manager(self, manager_name: str) -> Optional[Any]:
        """
        매니저 인스턴스를 반환합니다.
        
        Args:
            manager_name (str): 매니저 이름
            
        Returns:
            Optional[Any]: 매니저 인스턴스 또는 None
        """
        return self._managers.get(manager_name)
    
    def add_manager(self, manager_name: str, manager_instance: Any):
        """
        매니저를 추가합니다.
        
        Args:
            manager_name (str): 매니저 이름
            manager_instance (Any): 매니저 인스턴스
        """
        self._managers[manager_name] = manager_instance
        self._logger.info(f"매니저 추가: {manager_name}")
    
    def get_main_form(self) -> Optional[MainForm]:
        """메인 폼 인스턴스 반환"""
        return self._main_form
    
    def run(self):
        """애플리케이션 실행"""
        if not self._initialized:
            self._logger.error("애플리케이션이 초기화되지 않았습니다.")
            return
        
        try:
            self._logger.info("애플리케이션 실행 시작")
            
            if self._main_form:
                self._main_form.run()
            else:
                self._logger.error("메인 폼이 초기화되지 않았습니다.")
                
        except Exception as e:
            self._logger.exception(f"애플리케이션 실행 중 오류: {e}")
        finally:
            self._cleanup()
    
    def _cleanup(self):
        """정리 작업"""
        try:
            self._logger.info("애플리케이션 정리 작업 시작")
            
            # 로거 종료
            if self._logger:
                self._logger.shutdown()
            
            self._logger.info("애플리케이션 정리 작업 완료")
            
        except Exception as e:
            print(f"정리 작업 중 오류: {e}")
    
    def is_initialized(self) -> bool:
        """초기화 상태 확인"""
        return self._initialized 