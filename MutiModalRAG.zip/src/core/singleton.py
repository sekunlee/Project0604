"""
싱글턴 패턴 베이스 클래스
모든 매니저 클래스가 이 클래스를 상속받아 싱글턴 패턴을 구현합니다.
"""

import threading
from typing import Dict, Any


class Singleton:
    """
    싱글턴 패턴을 구현하는 베이스 클래스
    스레드 안전한 싱글턴 인스턴스 관리를 제공합니다.
    """
    
    _instances: Dict[str, Any] = {}
    _lock = threading.Lock()
    
    def __new__(cls, *args, **kwargs):
        """
        싱글턴 인스턴스를 생성하거나 기존 인스턴스를 반환합니다.
        스레드 안전성을 보장합니다.
        """
        if cls.__name__ not in cls._instances:
            with cls._lock:
                if cls.__name__ not in cls._instances:
                    cls._instances[cls.__name__] = super().__new__(cls)
        return cls._instances[cls.__name__]
    
    def __init__(self):
        """
        싱글턴 인스턴스 초기화
        이미 초기화된 경우 재초기화하지 않습니다.
        """
        if not hasattr(self, '_initialized'):
            self._initialized = True
            self._initialize()
    
    def _initialize(self):
        """
        하위 클래스에서 구현할 초기화 메서드
        """
        pass
    
    @classmethod
    def get_instance(cls):
        """
        싱글턴 인스턴스를 반환합니다.
        """
        return cls()
    
    @classmethod
    def clear_instance(cls):
        """
        싱글턴 인스턴스를 제거합니다 (테스트용).
        """
        if cls.__name__ in cls._instances:
            del cls._instances[cls.__name__] 