"""
빌드업 패턴 베이스 클래스
복잡한 객체 생성을 단계별로 분리하여 관리합니다.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class Builder(ABC):
    """
    빌드업 패턴의 추상 베이스 클래스
    복잡한 객체 생성을 위한 인터페이스를 정의합니다.
    """
    
    def __init__(self):
        """빌더 초기화"""
        self._product: Optional[Any] = None
        self._config: Dict[str, Any] = {}
    
    @abstractmethod
    def reset(self) -> 'Builder':
        """
        빌더 상태를 초기화합니다.
        
        Returns:
            Builder: 현재 빌더 인스턴스
        """
        pass
    
    @abstractmethod
    def build(self) -> Any:
        """
        최종 제품을 생성합니다.
        
        Returns:
            Any: 생성된 제품
        """
        pass
    
    def set_config(self, key: str, value: Any) -> 'Builder':
        """
        설정값을 추가합니다.
        
        Args:
            key (str): 설정 키
            value (Any): 설정 값
            
        Returns:
            Builder: 현재 빌더 인스턴스
        """
        self._config[key] = value
        return self
    
    def get_config(self, key: str, default: Any = None) -> Any:
        """
        설정값을 가져옵니다.
        
        Args:
            key (str): 설정 키
            default (Any): 기본값
            
        Returns:
            Any: 설정 값
        """
        return self._config.get(key, default)


class Director:
    """
    빌더를 사용하여 제품을 생성하는 디렉터 클래스
    """
    
    def __init__(self, builder: Builder):
        """
        디렉터 초기화
        
        Args:
            builder (Builder): 사용할 빌더 인스턴스
        """
        self._builder = builder
    
    def construct(self, config: Optional[Dict[str, Any]] = None) -> Any:
        """
        설정에 따라 제품을 생성합니다.
        
        Args:
            config (Optional[Dict[str, Any]]): 제품 생성 설정
            
        Returns:
            Any: 생성된 제품
        """
        self._builder.reset()
        
        if config:
            for key, value in config.items():
                self._builder.set_config(key, value)
        
        return self._builder.build() 