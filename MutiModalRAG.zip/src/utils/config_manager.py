"""
설정 관리 클래스
애플리케이션의 설정을 관리하는 매니저 클래스입니다.
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional

from ..core.singleton import Singleton
from ..log.logger import Logger


class ConfigManager(Singleton):
    """
    설정 관리 클래스
    JSON 파일을 통한 설정 관리와 기본값 제공을 담당합니다.
    """
    
    def _initialize(self):
        """설정 매니저 초기화"""
        self._logger = Logger.get_instance()
        self._config_file = Path("config.json")
        self._config: Dict[str, Any] = {}
        self._default_config = self._get_default_config()
        
        self._load_config()
        self._logger.info("설정 매니저 초기화 완료")
    
    def _get_default_config(self) -> Dict[str, Any]:
        """기본 설정값 반환"""
        return {
            "application": {
                "name": "MutiModalRAG",
                "version": "1.0.0",
                "debug": False
            },
            "gui": {
                "window_width": 1200,
                "window_height": 800,
                "maximized": True,
                "theme": "default"
            },
            "logging": {
                "level": "INFO",
                "file_rotation": True,
                "max_file_size": "10MB",
                "backup_count": 30
            },
            "ai": {
                "model_path": "models/",
                "preferred_model": "llama-2-3b-chat-ggml",
                "context_length": 512,
                "temperature": 0.7
            },
            "database": {
                "path": "data/",
                "auto_backup": True,
                "backup_interval": 24  # 시간
            }
        }
    
    def _load_config(self):
        """설정 파일 로드"""
        try:
            if self._config_file.exists():
                with open(self._config_file, 'r', encoding='utf-8') as f:
                    self._config = json.load(f)
                self._logger.info(f"설정 파일 로드 완료: {self._config_file}")
            else:
                self._config = self._default_config.copy()
                self._save_config()
                self._logger.info("기본 설정으로 초기화 완료")
                
        except Exception as e:
            self._logger.exception(f"설정 파일 로드 실패: {e}")
            self._config = self._default_config.copy()
    
    def _save_config(self):
        """설정 파일 저장"""
        try:
            # 설정 디렉토리 생성
            self._config_file.parent.mkdir(exist_ok=True)
            
            with open(self._config_file, 'w', encoding='utf-8') as f:
                json.dump(self._config, f, indent=2, ensure_ascii=False)
            
            self._logger.info(f"설정 파일 저장 완료: {self._config_file}")
            
        except Exception as e:
            self._logger.exception(f"설정 파일 저장 실패: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        설정값을 가져옵니다.
        
        Args:
            key (str): 설정 키 (점 표기법 지원: "gui.window_width")
            default (Any): 기본값
            
        Returns:
            Any: 설정값
        """
        try:
            keys = key.split('.')
            value = self._config
            
            for k in keys:
                if isinstance(value, dict) and k in value:
                    value = value[k]
                else:
                    return default
            
            return value
            
        except Exception as e:
            self._logger.warning(f"설정값 가져오기 실패: {key}, {e}")
            return default
    
    def set(self, key: str, value: Any):
        """
        설정값을 설정합니다.
        
        Args:
            key (str): 설정 키 (점 표기법 지원: "gui.window_width")
            value (Any): 설정값
        """
        try:
            keys = key.split('.')
            config = self._config
            
            # 마지막 키 전까지 순회하며 딕셔너리 생성
            for k in keys[:-1]:
                if k not in config:
                    config[k] = {}
                config = config[k]
            
            # 마지막 키에 값 설정
            config[keys[-1]] = value
            
            self._save_config()
            self._logger.info(f"설정값 설정 완료: {key} = {value}")
            
        except Exception as e:
            self._logger.exception(f"설정값 설정 실패: {key}, {e}")
    
    def get_all(self) -> Dict[str, Any]:
        """모든 설정값 반환"""
        return self._config.copy()
    
    def reset_to_default(self):
        """기본 설정으로 초기화"""
        try:
            self._config = self._default_config.copy()
            self._save_config()
            self._logger.info("설정을 기본값으로 초기화 완료")
            
        except Exception as e:
            self._logger.exception(f"설정 초기화 실패: {e}")
    
    def reload(self):
        """설정 파일 재로드"""
        self._load_config()
        self._logger.info("설정 파일 재로드 완료")
    
    def has_key(self, key: str) -> bool:
        """
        설정 키 존재 여부 확인
        
        Args:
            key (str): 설정 키
            
        Returns:
            bool: 키 존재 여부
        """
        return self.get(key) is not None 