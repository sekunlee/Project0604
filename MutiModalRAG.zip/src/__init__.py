"""
MutiModalRAG 소스 패키지
멀티모달 검색 시스템의 핵심 모듈들을 포함합니다.
"""

__version__ = "1.0.0"
__author__ = "MutiModalRAG Team" 