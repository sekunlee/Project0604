"""
메인 GUI 폼 클래스
애플리케이션의 메인 윈도우를 담당합니다.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sys
from typing import Optional

from ..core.singleton import Singleton
from ..log.logger import Logger


class MainForm(Singleton):
    """
    메인 GUI 폼 클래스
    싱글턴 패턴을 적용하여 애플리케이션 전체에서 하나의 메인 폼 인스턴스를 사용합니다.
    """
    
    def _initialize(self):
        """메인 폼 초기화"""
        self._root: Optional[tk.Tk] = None
        self._logger = Logger.get_instance()
        self._setup_main_window()
    
    def _setup_main_window(self):
        """메인 윈도우 설정"""
        try:
            self._root = tk.Tk()
            self._root.title("MutiModalRAG - 멀티모달 검색 시스템")
            
            # 윈도우 크기 및 위치 설정
            screen_width = self._root.winfo_screenwidth()
            screen_height = self._root.winfo_screenheight()
            
            # 최대화 설정
            self._root.state('zoomed')  # Windows에서 최대화
            
            # 윈도우 아이콘 설정 (선택사항)
            try:
                # 아이콘 파일이 있다면 설정
                pass
            except:
                pass
            
            # 윈도우 종료 이벤트 처리
            self._root.protocol("WM_DELETE_WINDOW", self._on_closing)
            
            # 메인 컨테이너 설정
            self._setup_main_container()
            
            self._logger.info("메인 윈도우 초기화 완료")
            
        except Exception as e:
            self._logger.exception(f"메인 윈도우 초기화 실패: {e}")
            messagebox.showerror("오류", f"메인 윈도우 초기화 중 오류가 발생했습니다:\n{e}")
            sys.exit(1)
    
    def _setup_main_container(self):
        """메인 컨테이너 설정"""
        if not self._root:
            return
        
        # 메인 프레임
        self._main_frame = ttk.Frame(self._root)
        self._main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 제목 레이블
        title_label = ttk.Label(
            self._main_frame, 
            text="MutiModalRAG - 멀티모달 검색 시스템",
            font=("Arial", 16, "bold")
        )
        title_label.pack(pady=(0, 20))
        
        # 상태 표시 레이블
        self._status_label = ttk.Label(
            self._main_frame,
            text="시스템 준비 완료",
            font=("Arial", 10)
        )
        self._status_label.pack(pady=(0, 10))
        
        # 메인 콘텐츠 영역 (향후 확장용)
        self._content_frame = ttk.Frame(self._main_frame)
        self._content_frame.pack(fill=tk.BOTH, expand=True)
        
        # 임시 메시지
        temp_label = ttk.Label(
            self._content_frame,
            text="GUI 구성이 완료되었습니다.\n향후 기능들이 이 영역에 추가됩니다.",
            font=("Arial", 12),
            justify=tk.CENTER
        )
        temp_label.pack(expand=True)
    
    def _on_closing(self):
        """윈도우 종료 처리"""
        try:
            self._logger.info("애플리케이션 종료 요청")
            
            # 종료 확인 다이얼로그
            if messagebox.askokcancel("종료", "애플리케이션을 종료하시겠습니까?"):
                self._logger.info("애플리케이션 종료")
                self._root.quit()
                self._root.destroy()
            else:
                self._logger.info("애플리케이션 종료 취소")
                
        except Exception as e:
            self._logger.exception(f"윈도우 종료 처리 중 오류: {e}")
            if self._root is not None:
                self._root.quit()
                self._root.destroy()
    
    def update_status(self, message: str):
        """
        상태 메시지를 업데이트합니다.
        
        Args:
            message (str): 새로운 상태 메시지
        """
        if self._status_label:
            self._status_label.config(text=message)
            self._logger.info(f"상태 업데이트: {message}")
    
    def show_message(self, title: str, message: str, message_type: str = "info"):
        """
        메시지 박스를 표시합니다.
        
        Args:
            title (str): 메시지 제목
            message (str): 메시지 내용
            message_type (str): 메시지 타입 (info, warning, error)
        """
        try:
            if message_type == "error":
                messagebox.showerror(title, message)
            elif message_type == "warning":
                messagebox.showwarning(title, message)
            else:
                messagebox.showinfo(title, message)
                
            self._logger.info(f"메시지 표시: {title} - {message}")
            
        except Exception as e:
            self._logger.exception(f"메시지 표시 중 오류: {e}")
    
    def run(self):
        """메인 이벤트 루프 실행"""
        if self._root:
            try:
                self._logger.info("GUI 이벤트 루프 시작")
                self._root.mainloop()
            except Exception as e:
                self._logger.exception(f"GUI 이벤트 루프 실행 중 오류: {e}")
        else:
            self._logger.error("메인 윈도우가 초기화되지 않았습니다.")
    
    def get_root(self) -> Optional[tk.Tk]:
        """루트 윈도우 반환"""
        return self._root 