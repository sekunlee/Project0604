"""
고성능 로그 시스템
다양한 로그 레벨과 비동기 처리를 지원하는 로그 시스템입니다.
Year/Month/Day 폴더 구조로 로그를 관리합니다.
"""

import logging
import logging.handlers
import os
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any
from queue import Queue


class Logger:
    """
    고성능 로그 시스템 클래스
    싱글턴 패턴을 적용하여 애플리케이션 전체에서 하나의 로그 인스턴스를 사용합니다.
    Year/Month/Day 폴더 구조로 로그를 관리합니다.
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, '_initialized'):
            self._initialized = True
            self._initialize()
    
    @classmethod
    def get_instance(cls):
        """싱글턴 인스턴스 반환"""
        return cls()
    
    def _initialize(self):
        """로거 초기화"""
        self._loggers: Dict[str, logging.Logger] = {}
        self._log_queue = Queue()
        self._log_thread = None
        self._running = False
        self._base_log_dir = Path("logs")
        self._current_date = datetime.now().date()
        self._setup_log_directory()
        self._start_log_thread()
    
    def _setup_log_directory(self):
        """로그 디렉토리 설정 (Year/Month/Day 구조)"""
        try:
            # Year/Month/Day 폴더 구조 생성
            year_dir = self._base_log_dir / str(self._current_date.year)
            month_dir = year_dir / f"{self._current_date.month:02d}"
            day_dir = month_dir / f"{self._current_date.day:02d}"
            
            # 각 폴더 생성
            year_dir.mkdir(exist_ok=True)
            month_dir.mkdir(exist_ok=True)
            day_dir.mkdir(exist_ok=True)
            
            self._log_dir = day_dir
            
        except Exception as e:
            print(f"로그 디렉토리 생성 실패: {e}")
            # 폴백: 기본 logs 폴더 사용
            self._log_dir = self._base_log_dir
            self._log_dir.mkdir(exist_ok=True)
    
    def _get_current_log_directory(self) -> Path:
        """현재 날짜에 해당하는 로그 디렉토리 반환"""
        current_date = datetime.now().date()
        
        # 날짜가 변경되었으면 새로운 디렉토리 생성
        if current_date != self._current_date:
            self._current_date = current_date
            self._setup_log_directory()
        
        return self._log_dir
    
    def _start_log_thread(self):
        """로그 처리 스레드 시작"""
        if not self._running:
            self._running = True
            self._log_thread = threading.Thread(target=self._process_log_queue, daemon=True)
            self._log_thread.start()
    
    def _process_log_queue(self):
        """로그 큐 처리 스레드"""
        while self._running:
            try:
                log_entry = self._log_queue.get(timeout=1)
                if log_entry is None:  # 종료 신호
                    break
                
                logger_name, level, message, extra = log_entry
                logger = self._get_logger(logger_name)
                logger.log(level, message, extra=extra)
                
            except Exception as e:
                print(f"로그 처리 중 오류: {e}")
    
    def _get_logger(self, name: str) -> logging.Logger:
        """로거 인스턴스 가져오기"""
        if name not in self._loggers:
            logger = logging.getLogger(name)
            logger.setLevel(logging.DEBUG)
            
            # 기존 핸들러 제거 (중복 방지)
            for handler in logger.handlers[:]:
                logger.removeHandler(handler)
            
            # 콘솔 핸들러
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(logging.INFO)
            console_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            console_handler.setFormatter(console_formatter)
            logger.addHandler(console_handler)
            
            # 현재 날짜의 로그 디렉토리 가져오기
            current_log_dir = self._get_current_log_directory()
            
            # 파일 핸들러 (일별 로테이션)
            log_file = current_log_dir / f"{name}.log"
            file_handler = logging.handlers.TimedRotatingFileHandler(
                log_file, when='midnight', interval=1, backupCount=30
            )
            file_handler.setLevel(logging.DEBUG)
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
            )
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)
            
            # 에러 로그 파일 핸들러
            error_log_file = current_log_dir / f"{name}_error.log"
            error_handler = logging.handlers.TimedRotatingFileHandler(
                error_log_file, when='midnight', interval=1, backupCount=30
            )
            error_handler.setLevel(logging.ERROR)
            error_handler.setFormatter(file_formatter)
            logger.addHandler(error_handler)
            
            self._loggers[name] = logger
        
        return self._loggers[name]
    
    def log(self, level: int, message: str, logger_name: str = "main", **kwargs):
        """
        로그 메시지를 큐에 추가합니다.
        
        Args:
            level (int): 로그 레벨
            message (str): 로그 메시지
            logger_name (str): 로거 이름
            **kwargs: 추가 정보
        """
        try:
            self._log_queue.put((logger_name, level, message, kwargs))
        except Exception as e:
            print(f"로그 큐 추가 실패: {e}")
    
    def debug(self, message: str, logger_name: str = "main", **kwargs):
        """DEBUG 레벨 로그"""
        self.log(logging.DEBUG, message, logger_name, **kwargs)
    
    def info(self, message: str, logger_name: str = "main", **kwargs):
        """INFO 레벨 로그"""
        self.log(logging.INFO, message, logger_name, **kwargs)
    
    def warning(self, message: str, logger_name: str = "main", **kwargs):
        """WARNING 레벨 로그"""
        self.log(logging.WARNING, message, logger_name, **kwargs)
    
    def error(self, message: str, logger_name: str = "main", **kwargs):
        """ERROR 레벨 로그"""
        self.log(logging.ERROR, message, logger_name, **kwargs)
    
    def critical(self, message: str, logger_name: str = "main", **kwargs):
        """CRITICAL 레벨 로그"""
        self.log(logging.CRITICAL, message, logger_name, **kwargs)
    
    def exception(self, message: str, logger_name: str = "main", **kwargs):
        """예외 정보와 함께 로그"""
        import traceback
        kwargs['exc_info'] = traceback.format_exc()
        self.log(logging.ERROR, message, logger_name, **kwargs)
    
    def get_log_directory(self) -> Path:
        """현재 로그 디렉토리 경로 반환"""
        return self._get_current_log_directory()
    
    def get_log_file_path(self, logger_name: str = "main", is_error: bool = False) -> Path:
        """
        로그 파일 경로 반환
        
        Args:
            logger_name (str): 로거 이름
            is_error (bool): 에러 로그 파일 여부
            
        Returns:
            Path: 로그 파일 경로
        """
        current_log_dir = self._get_current_log_directory()
        if is_error:
            return current_log_dir / f"{logger_name}_error.log"
        else:
            return current_log_dir / f"{logger_name}.log"
    
    def shutdown(self):
        """로거 종료"""
        self._running = False
        if self._log_queue:
            self._log_queue.put(None)  # 종료 신호
        if self._log_thread and self._log_thread.is_alive():
            self._log_thread.join(timeout=5) 