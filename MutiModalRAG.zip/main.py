#!/usr/bin/env python3
"""
MutiModalRAG - 멀티모달 검색 시스템
메인 시작 프로그램
"""

import sys
import os
from pathlib import Path

# 프로젝트 루트 디렉토리를 Python 경로에 추가
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

try:
    from src.core import Core
    from src.log import Logger
    from src.utils import ConfigManager
    
    def main():
        """메인 함수"""
        try:
            # 1. 로그 시스템 초기화
            logger = Logger.get_instance()
            logger.info("MutiModalRAG 애플리케이션 시작")
            
            # 2. 설정 매니저 초기화
            config_manager = ConfigManager.get_instance()
            logger.info("설정 매니저 초기화 완료")
            
            # 3. Core 클래스 초기화 및 애플리케이션 실행
            core = Core.get_instance()
            core.initialize_application()
            
            # 4. 애플리케이션 실행
            logger.info("애플리케이션 실행 시작")
            core.run()
            
        except KeyboardInterrupt:
            logger.info("사용자에 의한 애플리케이션 종료")
        except Exception as e:
            logger.exception(f"애플리케이션 실행 중 예상치 못한 오류: {e}")
            print(f"오류가 발생했습니다: {e}")
            sys.exit(1)
        finally:
            logger.info("MutiModalRAG 애플리케이션 종료")
    
    if __name__ == "__main__":
        main()
        
except ImportError as e:
    print(f"모듈 import 오류: {e}")
    print("가상환경이 활성화되어 있는지 확인해주세요.")
    print("필요한 패키지들이 설치되어 있는지 확인해주세요.")
    sys.exit(1)
except Exception as e:
    print(f"시작 프로그램 초기화 오류: {e}")
    sys.exit(1) 