import os
import shutil
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
from huggingface_hub import hf_hub_download
import requests
import logging
from datetime import datetime
import sys
import platform
import time
import subprocess
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor

# 로그 시스템 초기화 함수
def setup_logging():
    """로그 시스템을 초기화하고 파일과 콘솔에 로그를 기록할 수 있도록 설정"""
    # 로그 폴더 생성
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 로그 파일명 (날짜별로 생성)
    log_filename = f"logs/llm_loader_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    
    # 로거 설정
    logger = logging.getLogger('LlmLoader')
    logger.setLevel(logging.DEBUG)
    
    # 기존 핸들러 제거 (중복 방지)
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 파일 핸들러 설정 (상세 로그)
    file_handler = logging.FileHandler(log_filename, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)
    
    # 콘솔 핸들러 설정 (간단한 로그)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter('%(levelname)s: %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # 시스템 정보 로깅
    logger.info("=" * 60)
    logger.info("LLM Loader 애플리케이션 시작")
    logger.info(f"로그 파일: {log_filename}")
    logger.info(f"Python 버전: {sys.version}")
    logger.info(f"운영체제: {os.name} - {platform.platform()}")
    logger.info(f"작업 디렉토리: {os.getcwd()}")
    logger.info("=" * 60)
    
    return logger

def log_system_info():
    """시스템 정보를 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    try:
        import psutil
        logger.info("시스템 리소스 정보:")
        logger.info(f"  CPU 사용률: {psutil.cpu_percent(interval=1)}%")
        logger.info(f"  메모리 사용률: {psutil.virtual_memory().percent}%")
        logger.info(f"  디스크 사용률: {psutil.disk_usage('/').percent}%")
    except ImportError:
        logger.warning("psutil 모듈이 설치되지 않아 시스템 리소스 정보를 기록할 수 없습니다.")

def log_error_with_traceback(error, context=""):
    """오류와 스택 트레이스를 상세히 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    import traceback
    
    logger.error("=" * 40)
    logger.error(f"오류 발생: {context}")
    logger.error(f"오류 타입: {type(error).__name__}")
    logger.error(f"오류 메시지: {str(error)}")
    logger.error("스택 트레이스:")
    
    # 스택 트레이스를 로그에 기록
    for line in traceback.format_exc().split('\n'):
        if line.strip():
            logger.error(f"  {line}")
    
    logger.error("=" * 40)

def log_function_call(func_name, args=None, kwargs=None):
    """함수 호출을 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    logger.debug(f"함수 호출: {func_name}")
    if args:
        logger.debug(f"  위치 인수: {args}")
    if kwargs:
        logger.debug(f"  키워드 인수: {kwargs}")

def log_function_result(func_name, result, execution_time=None):
    """함수 실행 결과를 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    if execution_time:
        logger.debug(f"함수 완료: {func_name} (실행 시간: {execution_time:.3f}초)")
    else:
        logger.debug(f"함수 완료: {func_name}")
    
    if result is not None:
        if isinstance(result, (str, int, float, bool)):
            logger.debug(f"  반환값: {result}")
        else:
            logger.debug(f"  반환값 타입: {type(result).__name__}")

def log_performance_metric(operation, duration, details=""):
    """성능 메트릭을 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    if duration > 1.0:
        logger.warning(f"성능 경고: {operation}이 {duration:.3f}초 소요됨 {details}")
    else:
        logger.info(f"성능 정보: {operation} 완료 ({duration:.3f}초) {details}")

def log_network_request(url, method="GET", status_code=None, response_time=None):
    """네트워크 요청 정보를 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    logger.debug(f"네트워크 요청: {method} {url}")
    if status_code:
        logger.debug(f"  상태 코드: {status_code}")
    if response_time:
        logger.debug(f"  응답 시간: {response_time:.3f}초")

def log_model_operation(operation, model_name, platform, details=""):
    """모델 관련 작업을 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    logger.info(f"모델 작업: {operation} - {platform} - {model_name}")
    if details:
        logger.debug(f"  상세 정보: {details}")

def log_gui_event(event_type, widget_name, details=""):
    """GUI 이벤트를 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    logger.debug(f"GUI 이벤트: {event_type} - {widget_name}")
    if details:
        logger.debug(f"  상세 정보: {details}")

def log_user_action(action, details=""):
    """사용자 액션을 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    logger.info(f"사용자 액션: {action}")
    if details:
        logger.debug(f"  상세 정보: {details}")

def log_configuration(config_dict):
    """설정 정보를 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    logger.info("현재 설정:")
    for key, value in config_dict.items():
        logger.info(f"  {key}: {value}")

def log_memory_usage(label=""):
    """메모리 사용량을 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    try:
        import psutil
        process = psutil.Process()
        memory_info = process.memory_info()
        logger.debug(f"메모리 사용량 {label}: {memory_info.rss / 1024 / 1024:.2f} MB")
    except ImportError:
        pass

def log_file_operation(operation, file_path, success=True, details=""):
    """파일 작업을 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    if success:
        logger.info(f"파일 작업 성공: {operation} - {file_path}")
    else:
        logger.error(f"파일 작업 실패: {operation} - {file_path}")
    if details:
        logger.debug(f"  상세 정보: {details}")

def log_validation_result(validation_type, result, details=""):
    """검증 결과를 로그에 기록"""
    logger = logging.getLogger('LlmLoader')
    if result:
        logger.debug(f"검증 통과: {validation_type}")
    else:
        logger.warning(f"검증 실패: {validation_type}")
    if details:
        logger.debug(f"  상세 정보: {details}")

def log_exception_handler(func):
    """함수에 예외 처리와 로깅을 추가하는 데코레이터"""
    def wrapper(*args, **kwargs):
        logger = logging.getLogger('LlmLoader')
        start_time = time.time()
        
        try:
            log_function_call(func.__name__, args, kwargs)
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            log_function_result(func.__name__, result, execution_time)
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            log_error_with_traceback(e, f"{func.__name__} 함수 실행 중")
            log_function_result(func.__name__, None, execution_time)
            raise
    
    return wrapper

# 비동기 처리를 위한 유틸리티 함수들
def run_in_thread(func, *args, **kwargs):
    """함수를 별도 스레드에서 실행하고 결과를 반환"""
    def wrapper():
        try:
            return func(*args, **kwargs)
        except Exception as e:
            return None, str(e)
    
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(wrapper)
        return future.result()

def run_async_in_thread(coro):
    """비동기 함수를 별도 스레드에서 실행"""
    def wrapper():
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            return loop.run_until_complete(coro)
        except Exception as e:
            return None, str(e)
        finally:
            loop.close()
    
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(wrapper)
        return future.result()

async def async_requests_post(url, json_data=None, timeout=60, stream=False):
    """비동기 HTTP POST 요청 (requests 사용)"""
    def _post_request():
        return requests.post(url, json=json_data, timeout=timeout, stream=stream)
    
    return run_in_thread(_post_request)

async def async_requests_get(url, timeout=10):
    """비동기 HTTP GET 요청 (requests 사용)"""
    def _get_request():
        return requests.get(url, timeout=timeout)
    
    return run_in_thread(_get_request)

def update_gui_safely(root, func, *args, **kwargs):
    """GUI 업데이트를 메인 스레드에서 안전하게 실행"""
    if threading.current_thread() is threading.main_thread():
        return func(*args, **kwargs)
    else:
        root.after(0, lambda: func(*args, **kwargs))

# 백업 파일 생성 함수
@log_exception_handler
def create_backup(file_path):
    """파일 백업을 생성하고 로그를 기록"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_file_operation("백업 생성 시작", file_path)
    
    try:
        if os.path.exists(file_path):
            backup_path = file_path + ".bak"
            shutil.copy(file_path, backup_path)
            
            execution_time = time.time() - start_time
            log_file_operation("백업 생성", backup_path, True, f"소요 시간: {execution_time:.3f}초")
            log_performance_metric("백업 생성", execution_time, f"파일 크기: {os.path.getsize(backup_path)} bytes")
            
            return backup_path
        else:
            logger.warning(f"백업할 파일이 존재하지 않음: {file_path}")
            log_file_operation("백업 생성", file_path, False, "파일이 존재하지 않음")
            return None
    except Exception as e:
        execution_time = time.time() - start_time
        log_error_with_traceback(e, f"백업 파일 생성 중 - {file_path}")
        log_file_operation("백업 생성", file_path, False, f"오류: {str(e)}")
        return None

# 모델 다운로드 함수 (HuggingFace)
@log_exception_handler
def download_model_huggingface(model_repo, model_filename, save_dir, progress_callback=None):
    """HuggingFace에서 모델을 다운로드하고 로그를 기록"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_model_operation("다운로드 시작", model_filename, "HuggingFace", f"저장 경로: {save_dir}")
    log_user_action("HuggingFace 모델 다운로드", f"모델: {model_repo}/{model_filename}")
    
    try:
        # 저장 디렉토리 검증
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
            log_file_operation("디렉토리 생성", save_dir, True)
        
        if progress_callback:
            progress_callback(5, "HuggingFace 연결 중...")
        
        # 네트워크 요청 로깅
        log_network_request(f"huggingface.co/{model_repo}", "GET")
        
        # huggingface_hub를 이용해 모델 파일 다운로드 (진행률 표시 포함)
        if progress_callback:
            progress_callback(10, "모델 정보 확인 중...")
            
        file_path = hf_hub_download(
            repo_id=model_repo, 
            filename=model_filename, 
            local_dir=save_dir
        )
        
        if progress_callback:
            progress_callback(100, "다운로드 완료")
        
        execution_time = time.time() - start_time
        log_model_operation("다운로드 완료", model_filename, "HuggingFace", f"파일 경로: {file_path}")
        log_performance_metric("HuggingFace 모델 다운로드", execution_time, f"파일 크기: {os.path.getsize(file_path)} bytes")
        log_file_operation("모델 파일 다운로드", file_path, True, f"소요 시간: {execution_time:.3f}초")
        
        return file_path, None
    except Exception as e:
        execution_time = time.time() - start_time
        log_error_with_traceback(e, f"HuggingFace 모델 다운로드 중 - {model_repo}/{model_filename}")
        log_model_operation("다운로드 실패", model_filename, "HuggingFace", f"오류: {str(e)}")
        log_performance_metric("HuggingFace 모델 다운로드 (실패)", execution_time)
        
        if progress_callback:
            progress_callback(0, "다운로드 실패")
        return None, str(e)

# 모델 다운로드 함수 (Ollama)
@log_exception_handler
def download_model_ollama(model_name, save_dir, progress_callback=None):
    """Ollama에서 모델을 다운로드하고 로그를 기록 (비동기 처리)"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_model_operation("다운로드 시작", model_name, "Ollama", f"저장 경로: {save_dir}")
    log_user_action("Ollama 모델 다운로드", f"모델: {model_name}")
    
    def _download_model():
        """실제 모델 다운로드 로직"""
        try:
            # Ollama 기본 설치 위치 설정 (사용자 입력 경로 무시)
            ollama_path = os.path.expanduser("~/.ollama")
            if os.name == 'nt':  # Windows
                ollama_path = os.path.join(os.path.expanduser("~"), ".ollama")
            
            logger.debug(f"Ollama 설치 경로: {ollama_path}")
            
            # Ollama 서버 상태 확인
            try:
                log_network_request("http://localhost:11434/api/tags", "GET")
                status_response = requests.get("http://localhost:11434/api/tags", timeout=5)
                log_network_request("http://localhost:11434/api/tags", "GET", status_response.status_code)
                
                if status_response.status_code != 200:
                    logger.error(f"Ollama 서버 상태 확인 실패: {status_response.status_code}")
                    log_validation_result("Ollama 서버 상태", False, f"상태 코드: {status_response.status_code}")
                    return None, "Ollama 서버가 정상적으로 실행되지 않습니다."
                else:
                    log_validation_result("Ollama 서버 상태", True)
            except requests.exceptions.RequestException as e:
                logger.error(f"Ollama 서버 연결 실패: {str(e)}")
                log_network_request("http://localhost:11434/api/tags", "GET", None, None)
                log_error_with_traceback(e, "Ollama 서버 연결 시도 중")
                return None, "Ollama 서버에 연결할 수 없습니다. Ollama가 실행 중인지 확인해주세요."
            
            # 모델 다운로드 요청 (스트리밍 응답 처리)
            pull_url = "http://localhost:11434/api/pull"
            pull_data = {"name": model_name}
            
            logger.debug(f"Ollama pull 요청: {pull_url}, 데이터: {pull_data}")
            log_network_request(pull_url, "POST")
            
            # 타임아웃 설정 (다운로드는 시간이 오래 걸릴 수 있음)
            response = requests.post(pull_url, json=pull_data, timeout=300, stream=True)
            
            if response.status_code == 200:
                # 스트리밍 응답 처리
                download_completed = False
                total_layers = 0
                completed_layers = 0
                last_progress = 0
                
                for line in response.iter_lines():
                    if line:
                        try:
                            data = line.decode('utf-8')
                            logger.debug(f"Ollama 응답: {data}")
                            
                            # JSON 응답 파싱 시도
                            if data.startswith('{'):
                                import json
                                try:
                                    json_data = json.loads(data)
                                    
                                    # 다운로드 상태 확인
                                    if 'status' in json_data:
                                        status = json_data['status']
                                        
                                        if status == 'success':
                                            download_completed = True
                                            if progress_callback:
                                                progress_callback(100, "다운로드 완료")
                                            logger.info("Ollama 모델 다운로드 완료")
                                            break
                                        elif status == 'error':
                                            error_msg = json_data.get('error', '알 수 없는 오류')
                                            logger.error(f"Ollama 다운로드 오류: {error_msg}")
                                            log_model_operation("다운로드 오류", model_name, "Ollama", error_msg)
                                            return None, f"다운로드 실패: {error_msg}"
                                    
                                    # 진행률 정보 처리
                                    if 'total' in json_data and 'completed' in json_data:
                                        total_layers = json_data.get('total', 0)
                                        completed_layers = json_data.get('completed', 0)
                                        
                                        if total_layers > 0:
                                            progress = int((completed_layers / total_layers) * 100)
                                            if progress != last_progress:
                                                progress_text = f"다운로드 중... {progress}% ({completed_layers}/{total_layers} 레이어)"
                                                logger.info(f"다운로드 진행률: {progress}%")
                                                if progress_callback:
                                                    progress_callback(progress, progress_text)
                                                last_progress = progress
                                    
                                    # 개별 레이어 다운로드 상태
                                    elif 'digest' in json_data and 'status' in json_data:
                                        layer_status = json_data.get('status', '')
                                        if layer_status == 'downloading':
                                            completed_layers += 1
                                            if total_layers > 0:
                                                progress = int((completed_layers / total_layers) * 100)
                                                if progress != last_progress:
                                                    progress_text = f"다운로드 중... {progress}% ({completed_layers}/{total_layers} 레이어)"
                                                    logger.info(f"다운로드 진행률: {progress}%")
                                                    if progress_callback:
                                                        progress_callback(progress, progress_text)
                                                    last_progress = progress
                                    
                                except json.JSONDecodeError:
                                    logger.debug(f"JSON 파싱 실패: {data}")
                                    continue
                        except UnicodeDecodeError:
                            logger.debug(f"응답 디코딩 실패: {line}")
                            continue
                
                if download_completed:
                    execution_time = time.time() - start_time
                    log_model_operation("다운로드 완료", model_name, "Ollama")
                    log_performance_metric("Ollama 모델 다운로드", execution_time, f"총 레이어: {total_layers}")
                    return model_name, None
                else:
                    logger.error("Ollama 모델 다운로드가 완료되지 않음")
                    log_model_operation("다운로드 실패", model_name, "Ollama", "완료 신호를 받지 못함")
                    return None, "다운로드가 완료되지 않았습니다."
            else:
                logger.error(f"Ollama pull 요청 실패: {response.status_code}")
                log_network_request(pull_url, "POST", response.status_code)
                return None, f"다운로드 요청 실패: {response.status_code}"
                
        except Exception as e:
            execution_time = time.time() - start_time
            log_error_with_traceback(e, f"Ollama 모델 다운로드 중 - {model_name}")
            log_model_operation("다운로드 실패", model_name, "Ollama", f"오류: {str(e)}")
            log_performance_metric("Ollama 모델 다운로드 (실패)", execution_time)
            
            if progress_callback:
                progress_callback(0, "다운로드 실패")
            return None, str(e)
    
    # 별도 스레드에서 실행
    return run_in_thread(_download_model)

# Ollama 서버 상태 확인 함수
@log_exception_handler
def check_ollama_server():
    """Ollama 서버 상태를 확인하고 로그를 기록"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_network_request("http://localhost:11434/api/tags", "GET")
    
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=5)
        execution_time = time.time() - start_time
        
        log_network_request("http://localhost:11434/api/tags", "GET", response.status_code, execution_time)
        
        if response.status_code == 200:
            logger.info("Ollama 서버가 정상적으로 실행 중입니다.")
            log_validation_result("Ollama 서버 상태", True, f"응답 시간: {execution_time:.3f}초")
            return True, "Ollama 서버가 정상적으로 실행 중입니다."
        else:
            logger.error(f"Ollama 서버 상태 확인 실패: {response.status_code}")
            log_validation_result("Ollama 서버 상태", False, f"상태 코드: {response.status_code}")
            return False, f"Ollama 서버 상태 확인 실패: {response.status_code}"
    except requests.exceptions.RequestException as e:
        execution_time = time.time() - start_time
        log_error_with_traceback(e, "Ollama 서버 상태 확인 중")
        log_network_request("http://localhost:11434/api/tags", "GET", None, execution_time)
        return False, f"Ollama 서버 연결 실패: {str(e)}"

# Ollama 모델 목록 조회 함수
@log_exception_handler
def get_ollama_models():
    """Ollama에 설치된 모델 목록을 조회하고 로그를 기록 (비동기 처리)"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_network_request("http://localhost:11434/api/tags", "GET")
    
    def _get_models():
        """실제 모델 목록 조회 로직"""
        try:
            response = requests.get("http://localhost:11434/api/tags", timeout=10)
            execution_time = time.time() - start_time
            
            log_network_request("http://localhost:11434/api/tags", "GET", response.status_code, execution_time)
            
            if response.status_code == 200:
                models_data = response.json()
                models = [model['name'] for model in models_data.get('models', [])]
                
                logger.info(f"Ollama 모델 목록 조회 완료: {len(models)}개 모델")
                log_model_operation("목록 조회", f"{len(models)}개 모델", "Ollama", f"모델: {', '.join(models)}")
                log_performance_metric("Ollama 모델 목록 조회", execution_time, f"조회된 모델 수: {len(models)}")
                
                return models
            else:
                logger.error(f"Ollama 모델 목록 조회 실패: {response.status_code}")
                log_validation_result("Ollama 모델 목록 조회", False, f"상태 코드: {response.status_code}")
                return []
        except requests.exceptions.RequestException as e:
            execution_time = time.time() - start_time
            log_error_with_traceback(e, "Ollama 모델 목록 조회 중")
            log_network_request("http://localhost:11434/api/tags", "GET", None, execution_time)
            return []
        except Exception as e:
            execution_time = time.time() - start_time
            log_error_with_traceback(e, "Ollama 모델 목록 조회 중")
            return []
    
    # 별도 스레드에서 실행
    return run_in_thread(_get_models)

# Ollama 모델 로딩 함수
@log_exception_handler
def load_ollama_model(model_name):
    """Ollama 모델을 로딩하고 로그를 기록"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_model_operation("로딩 시작", model_name, "Ollama")
    log_user_action("Ollama 모델 로딩", f"모델: {model_name}")
    
    try:
        # 모델 로딩 요청
        load_url = "http://localhost:11434/api/generate"
        load_data = {
            "model": model_name,
            "prompt": "Hello",
            "stream": False
        }
        
        log_network_request(load_url, "POST")
        
        response = requests.post(load_url, json=load_data, timeout=30)
        execution_time = time.time() - start_time
        
        log_network_request(load_url, "POST", response.status_code, execution_time)
        
        if response.status_code == 200:
            logger.info(f"Ollama 모델 로딩 완료: {model_name}")
            log_model_operation("로딩 완료", model_name, "Ollama")
            log_performance_metric("Ollama 모델 로딩", execution_time)
            return True, f"모델 '{model_name}' 로딩 완료"
        else:
            logger.error(f"Ollama 모델 로딩 실패: {response.status_code}")
            log_model_operation("로딩 실패", model_name, "Ollama", f"상태 코드: {response.status_code}")
            return False, f"모델 로딩 실패: {response.status_code}"
    except requests.exceptions.RequestException as e:
        execution_time = time.time() - start_time
        log_error_with_traceback(e, f"Ollama 모델 로딩 중 - {model_name}")
        log_model_operation("로딩 실패", model_name, "Ollama", f"네트워크 오류: {str(e)}")
        return False, f"네트워크 오류: {str(e)}"
    except Exception as e:
        execution_time = time.time() - start_time
        log_error_with_traceback(e, f"Ollama 모델 로딩 중 - {model_name}")
        log_model_operation("로딩 실패", model_name, "Ollama", f"오류: {str(e)}")
        return False, f"로딩 오류: {str(e)}"

# Ollama 모델 테스트 함수
@log_exception_handler
def test_ollama_model(model_name, prompt, progress_callback=None):
    """Ollama 모델을 테스트하고 로그를 기록 (비동기 처리)"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_model_operation("테스트 시작", model_name, "Ollama", f"프롬프트: {prompt[:50]}...")
    log_user_action("Ollama 모델 테스트", f"모델: {model_name}, 프롬프트: {prompt[:50]}...")
    
    def _test_model():
        """실제 모델 테스트 로직"""
        try:
            if progress_callback:
                progress_callback(10, "모델 연결 중...")
            
            # 모델 테스트 요청
            test_url = "http://localhost:11434/api/generate"
            test_data = {
                "model": model_name,
                "prompt": prompt,
                "stream": False
            }
            
            log_network_request(test_url, "POST")
            
            if progress_callback:
                progress_callback(30, "응답 생성 중...")
            
            response = requests.post(test_url, json=test_data, timeout=60)
            execution_time = time.time() - start_time
            
            log_network_request(test_url, "POST", response.status_code, execution_time)
            
            if response.status_code == 200:
                response_data = response.json()
                answer = response_data.get('response', '')
                
                if progress_callback:
                    progress_callback(100, "테스트 완료")
                
                logger.info(f"Ollama 모델 테스트 완료: {model_name}")
                logger.info(f"응답 내용: {answer}")  # 응답 내용을 로그에 기록
                log_model_operation("테스트 완료", model_name, "Ollama", f"응답 길이: {len(answer)} 문자, 응답: {answer[:100]}...")
                log_performance_metric("Ollama 모델 테스트", execution_time, f"응답 길이: {len(answer)} 문자")
                
                return answer, None
            else:
                logger.error(f"Ollama 모델 테스트 실패: {response.status_code}")
                log_model_operation("테스트 실패", model_name, "Ollama", f"상태 코드: {response.status_code}")
                
                if progress_callback:
                    progress_callback(0, "테스트 실패")
                
                return None, f"테스트 실패: {response.status_code}"
        except requests.exceptions.RequestException as e:
            execution_time = time.time() - start_time
            log_error_with_traceback(e, f"Ollama 모델 테스트 중 - {model_name}")
            log_model_operation("테스트 실패", model_name, "Ollama", f"네트워크 오류: {str(e)}")
            
            if progress_callback:
                progress_callback(0, "테스트 실패")
            
            return None, f"네트워크 오류: {str(e)}"
        except Exception as e:
            execution_time = time.time() - start_time
            log_error_with_traceback(e, f"Ollama 모델 테스트 중 - {model_name}")
            log_model_operation("테스트 실패", model_name, "Ollama", f"오류: {str(e)}")
            
            if progress_callback:
                progress_callback(0, "테스트 실패")
            
            return None, f"테스트 오류: {str(e)}"
    
    # 별도 스레드에서 실행
    return run_in_thread(_test_model)

# HuggingFace 모델 로딩 함수
@log_exception_handler
def load_huggingface_model(model_path):
    """HuggingFace 모델을 로딩하고 로그를 기록"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_model_operation("로딩 시작", os.path.basename(model_path), "HuggingFace", f"경로: {model_path}")
    log_user_action("HuggingFace 모델 로딩", f"경로: {model_path}")
    
    try:
        # 모델 파일 존재 확인
        if not os.path.exists(model_path):
            logger.error(f"모델 파일이 존재하지 않음: {model_path}")
            log_file_operation("모델 파일 확인", model_path, False, "파일이 존재하지 않음")
            return False, f"모델 파일이 존재하지 않습니다: {model_path}"
        
        log_file_operation("모델 파일 확인", model_path, True, f"파일 크기: {os.path.getsize(model_path)} bytes")
        
        # 여기에 실제 모델 로딩 로직을 추가할 수 있습니다
        # 현재는 파일 존재 여부만 확인
        
        execution_time = time.time() - start_time
        logger.info(f"HuggingFace 모델 로딩 완료: {model_path}")
        log_model_operation("로딩 완료", os.path.basename(model_path), "HuggingFace")
        log_performance_metric("HuggingFace 모델 로딩", execution_time)
        
        return True, f"모델 로딩 완료: {os.path.basename(model_path)}"
    except Exception as e:
        execution_time = time.time() - start_time
        log_error_with_traceback(e, f"HuggingFace 모델 로딩 중 - {model_path}")
        log_model_operation("로딩 실패", os.path.basename(model_path), "HuggingFace", f"오류: {str(e)}")
        return False, f"로딩 오류: {str(e)}"

# HuggingFace 모델 테스트 함수
@log_exception_handler
def test_huggingface_model(model_path, prompt, progress_callback=None):
    """HuggingFace 모델을 테스트하고 로그를 기록"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_model_operation("테스트 시작", os.path.basename(model_path), "HuggingFace", f"프롬프트: {prompt[:50]}...")
    log_user_action("HuggingFace 모델 테스트", f"경로: {model_path}, 프롬프트: {prompt[:50]}...")
    
    try:
        if progress_callback:
            progress_callback(10, "모델 로딩 중...")
        
        # 모델 파일 존재 확인
        if not os.path.exists(model_path):
            logger.error(f"모델 파일이 존재하지 않음: {model_path}")
            log_file_operation("모델 파일 확인", model_path, False, "파일이 존재하지 않음")
            
            if progress_callback:
                progress_callback(0, "테스트 실패")
            
            return None, f"모델 파일이 존재하지 않습니다: {model_path}"
        
        if progress_callback:
            progress_callback(50, "모델 처리 중...")
        
        # 여기에 실제 모델 테스트 로직을 추가할 수 있습니다
        # 현재는 더미 응답을 반환
        
        execution_time = time.time() - start_time
        
        if progress_callback:
            progress_callback(100, "테스트 완료")
        
        dummy_response = f"[HuggingFace 모델 테스트] 프롬프트: {prompt}\n\n이것은 HuggingFace 모델의 테스트 응답입니다."
        
        logger.info(f"HuggingFace 모델 테스트 완료: {model_path}")
        log_model_operation("테스트 완료", os.path.basename(model_path), "HuggingFace", f"응답 길이: {len(dummy_response)} 문자")
        log_performance_metric("HuggingFace 모델 테스트", execution_time, f"응답 길이: {len(dummy_response)} 문자")
        
        return dummy_response, None
    except Exception as e:
        execution_time = time.time() - start_time
        log_error_with_traceback(e, f"HuggingFace 모델 테스트 중 - {model_path}")
        log_model_operation("테스트 실패", os.path.basename(model_path), "HuggingFace", f"오류: {str(e)}")
        
        if progress_callback:
            progress_callback(0, "테스트 실패")
        
        return None, f"테스트 오류: {str(e)}"

# Ollama 모델 목록 업데이트 함수
def update_ollama_model_list():
    """Ollama 설치된 모델 목록을 가져와서 콤보박스에 업데이트"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_model_operation("목록 업데이트 시작", "Ollama 모델", "Ollama")
    
    try:
        # 기본값 설정
        model_list = ["모델을 선택하세요"]
        
        # Ollama 모델 목록 가져오기
        models_result = get_ollama_models()
        if isinstance(models_result, tuple):
            models, error = models_result
            if error:
                logger.error(f"모델 목록 조회 실패: {error}")
                log_model_operation("목록 업데이트 실패", "모델 목록", "Ollama", f"오류: {error}")
                return model_list
        else:
            models = models_result
        
        if models:
            model_list.extend(models)
            logger.info(f"Ollama 모델 목록 업데이트 완료: {len(models)}개 모델")
            log_model_operation("목록 업데이트 완료", f"{len(models)}개 모델", "Ollama", f"모델: {', '.join(models)}")
        else:
            logger.warning("Ollama 모델 목록 가져오기 실패")
            log_model_operation("목록 업데이트 실패", "모델 목록", "Ollama", "모델 목록을 가져올 수 없음")
        
        execution_time = time.time() - start_time
        log_performance_metric("Ollama 모델 목록 업데이트", execution_time, f"처리된 모델 수: {len(models) if models else 0}")
        
        return model_list
        
    except Exception as e:
        execution_time = time.time() - start_time
        log_error_with_traceback(e, "Ollama 모델 목록 업데이트 중")
        log_model_operation("목록 업데이트 실패", "모델 목록", "Ollama", f"오류: {str(e)}")
        
        # 오류 발생 시 기본값 반환
        return ["모델을 선택하세요"]

# 메인 GUI 클래스
def main():
    """메인 GUI 애플리케이션"""
    # 로그 시스템 초기화
    logger = setup_logging()
    
    # 시스템 정보 로깅
    log_system_info()
    
    # 애플리케이션 설정 로깅
    app_config = {
        "애플리케이션": "LLM Loader",
        "버전": "1.0",
        "Python 버전": sys.version,
        "운영체제": platform.platform(),
        "작업 디렉토리": os.getcwd()
    }
    log_configuration(app_config)
    
    log_user_action("애플리케이션 시작")
    
    # tkinter 윈도우 생성
    root = tk.Tk()
    root.title("LLM 모델 다운로드 및 테스트 프로그램")
    root.geometry("600x750")
    
    logger.debug("GUI 윈도우 생성 완료")
    log_gui_event("윈도우 생성", "root", "크기: 600x750")

    # 플랫폼 선택 콤보박스
    tk.Label(root, text="플랫폼 선택:").pack(anchor="w", padx=10, pady=5)
    platform_var = tk.StringVar()
    platform_combo = ttk.Combobox(root, textvariable=platform_var, state="readonly")
    platform_combo['values'] = ("HuggingFace", "Ollama")
    platform_combo.current(0)
    platform_combo.pack(fill="x", padx=10)
    
    # 플랫폼 선택 시 도움말 텍스트 변경
    def update_help_text(*args):
        """플랫폼 선택에 따라 도움말 텍스트를 업데이트"""
        platform = platform_var.get()
        log_gui_event("플랫폼 선택", "platform_combo", f"선택된 플랫폼: {platform}")
        log_user_action("플랫폼 변경", f"새 플랫폼: {platform}")
        
        if platform == "HuggingFace":
            help_text.set("예시: 'TheBloke/Llama-2-7B-Chat-GGML', 'TheBloke/Llama-2-3B-Chat-GGML'")
            # HuggingFace 선택 시 저장 경로 활성화
            save_dir_entry.config(state="normal")
            select_dir_btn.config(state="normal")
            log_gui_event("UI 상태 변경", "save_dir_entry", "활성화됨")
            # HuggingFace 모델 목록 업데이트 (현재는 기본값)
            installed_model_combo['values'] = ["모델을 선택하세요"]
            installed_model_var.set("모델을 선택하세요")
        elif platform == "Ollama":
            help_text.set("예시: 'gemma3', 'llama3', 'mistral', 'codellama' (명령어 제외)")
            # Ollama 선택 시 저장 경로를 Ollama 기본 위치로 설정하고 비활성화
            ollama_path = os.path.join(os.path.expanduser("~"), ".ollama")
            save_dir_entry.config(state="normal")
            save_dir_entry.delete(0, tk.END)
            save_dir_entry.insert(0, ollama_path)
            save_dir_entry.config(state="disabled")
            select_dir_btn.config(state="disabled")
            log_gui_event("UI 상태 변경", "save_dir_entry", f"비활성화됨, 경로: {ollama_path}")
            # Ollama 모델 목록 업데이트
            model_list = update_ollama_model_list()
            installed_model_combo['values'] = model_list
            installed_model_var.set("모델을 선택하세요")
            log_gui_event("콤보박스 업데이트", "installed_model_combo", f"{len(model_list)-1}개 모델 추가됨")
    
    platform_var.trace('w', update_help_text)

    # 모델명/레포 입력
    tk.Label(root, text="모델 레포/이름:").pack(anchor="w", padx=10, pady=5)
    model_entry = tk.Entry(root)
    model_entry.pack(fill="x", padx=10)
    
    # 설치된 모델 선택 콤보박스
    tk.Label(root, text="설치된 모델 선택:").pack(anchor="w", padx=10, pady=5)
    installed_model_var = tk.StringVar()
    installed_model_combo = ttk.Combobox(root, textvariable=installed_model_var, state="readonly")
    installed_model_combo['values'] = ["모델을 선택하세요"]
    installed_model_var.set("모델을 선택하세요")
    installed_model_combo.pack(fill="x", padx=10)
    
    # 모델 선택 시 모델명 입력 필드에 자동 입력
    def on_model_select(*args):
        """설치된 모델 선택 시 모델명 입력 필드에 자동 입력"""
        selected_model = installed_model_var.get()
        if selected_model and selected_model != "모델을 선택하세요":
            # 모델명만 추출 (크기 정보 제거)
            model_name = selected_model.split(' (')[0]
            model_entry.delete(0, tk.END)
            model_entry.insert(0, model_name)
            log_gui_event("모델 선택", "installed_model_combo", f"선택된 모델: {model_name}")
            log_user_action("모델 선택", f"모델: {model_name}")
    
    installed_model_var.trace('w', on_model_select)
    
    # 모델명 도움말 텍스트
    help_text = tk.StringVar()
    help_text.set("HuggingFace: 'TheBloke/Llama-2-7B-Chat-GGML' | Ollama: 'gemma3', 'llama3', 'mistral'")
    help_label = tk.Label(root, textvariable=help_text, fg="gray", font=("Arial", 8))
    help_label.pack(anchor="w", padx=10, pady=2)

    # (HuggingFace 전용) 파일명 입력
    tk.Label(root, text="(HuggingFace 전용) 모델 파일명:").pack(anchor="w", padx=10, pady=5)
    model_file_entry = tk.Entry(root)
    model_file_entry.pack(fill="x", padx=10)
    model_file_entry.insert(0, "ggml-model.bin")

    # 다운로드 경로 입력
    tk.Label(root, text="저장 경로:").pack(anchor="w", padx=10, pady=5)
    save_dir_frame = tk.Frame(root)
    save_dir_frame.pack(fill="x", padx=10)
    save_dir_entry = tk.Entry(save_dir_frame)
    save_dir_entry.pack(side="left", fill="x", expand=True)
    save_dir_entry.insert(0, "models")
    # 폴더 선택 버튼 클릭 시 다이얼로그 열기
    def select_save_dir():
        log_user_action("저장 경로 선택", "폴더 선택 다이얼로그 열기")
        folder_selected = filedialog.askdirectory()
        if folder_selected:
            save_dir_entry.delete(0, tk.END)
            save_dir_entry.insert(0, folder_selected)
            log_gui_event("경로 선택", "save_dir_entry", f"선택된 경로: {folder_selected}")
            log_user_action("저장 경로 변경", f"새 경로: {folder_selected}")
    select_dir_btn = tk.Button(save_dir_frame, text="경로 선택", command=select_save_dir)
    select_dir_btn.pack(side="right", padx=5)

    # Ollama 서버 상태 확인 버튼 (Ollama 선택 시에만 활성화)
    def check_ollama_status():
        """Ollama 서버 상태 확인 버튼 클릭 시 실행되는 함수"""
        logger = logging.getLogger('LlmLoader')
        logger.info("Ollama 서버 상태 확인 요청")
        log_user_action("Ollama 서버 상태 확인", "버튼 클릭")
        
        try:
            success, message = check_ollama_server()
            if success:
                messagebox.showinfo("Ollama 서버 상태", message)
                logger.info("Ollama 서버 상태 확인 완료")
                log_user_action("Ollama 서버 상태 확인", "성공")
            else:
                messagebox.showerror("Ollama 서버 오류", message)
                logger.error("Ollama 서버 상태 확인 실패")
                log_user_action("Ollama 서버 상태 확인", f"실패: {message}")
        except Exception as e:
            logger.error(f"Ollama 서버 상태 확인 중 예외 발생: {str(e)}")
            log_error_with_traceback(e, "Ollama 서버 상태 확인 중")
            messagebox.showerror("오류", f"서버 상태 확인 중 오류가 발생했습니다:\n{str(e)}")

    def show_ollama_models():
        """Ollama 모델 목록 조회 버튼 클릭 시 실행되는 함수"""
        logger = logging.getLogger('LlmLoader')
        logger.info("Ollama 모델 목록 조회 요청")
        log_user_action("Ollama 모델 목록 조회", "버튼 클릭")
        
        try:
            models_result = get_ollama_models()
            if isinstance(models_result, tuple):
                models, error = models_result
                if error:
                    logger.error(f"모델 목록 조회 실패: {error}")
                    messagebox.showerror("오류", f"모델 목록 조회에 실패했습니다:\n{error}")
                    return
            else:
                models = models_result
            
            if models:
                model_list_text = "\n".join(models)
                messagebox.showinfo("Ollama 모델 목록", f"설치된 모델 목록:\n\n{model_list_text}")
                logger.info("Ollama 모델 목록 조회 완료")
                log_user_action("Ollama 모델 목록 조회", f"성공: {len(models)}개 모델")
            else:
                messagebox.showinfo("Ollama 모델 목록", "설치된 모델이 없습니다.")
                logger.info("Ollama 모델 목록 조회 완료 (모델 없음)")
                log_user_action("Ollama 모델 목록 조회", "성공: 모델 없음")
        except Exception as e:
            logger.error(f"Ollama 모델 목록 조회 중 예외 발생: {str(e)}")
            log_error_with_traceback(e, "Ollama 모델 목록 조회 중")
            messagebox.showerror("오류", f"모델 목록 조회 중 오류가 발생했습니다:\n{str(e)}")

    # Ollama 관련 버튼 프레임
    ollama_frame = tk.Frame(root)
    ollama_frame.pack(fill="x", padx=10, pady=5)
    
    ollama_status_btn = tk.Button(ollama_frame, text="Ollama 서버 상태 확인", command=check_ollama_status)
    ollama_status_btn.pack(side="left", padx=5)
    
    ollama_models_btn = tk.Button(ollama_frame, text="설치된 모델 목록", command=show_ollama_models)
    ollama_models_btn.pack(side="left", padx=5)
    
    def delete_selected_model():
        """선택된 모델을 삭제하는 함수 (비동기 처리)"""
        logger = logging.getLogger('LlmLoader')
        
        # 입력값 가져오기
        platform = platform_var.get()
        selected_model = installed_model_var.get()
        
        logger.info(f"모델 삭제 요청: 플랫폼={platform}, 선택된 모델={selected_model}")
        
        # 플랫폼 확인
        if platform != "Ollama":
            logger.warning("Ollama가 아닌 플랫폼에서 삭제 시도")
            messagebox.showwarning("경고", "현재 Ollama 모델만 삭제할 수 있습니다.")
            return
        
        # 모델 선택 확인
        if selected_model == "모델을 선택하세요" or not selected_model:
            logger.warning("모델이 선택되지 않음")
            messagebox.showwarning("경고", "삭제할 모델을 선택해주세요.")
            return
        
        # 모델명 추출 (크기 정보 제거)
        model_name = selected_model.split(' (')[0]
        
        # 삭제 확인 대화상자
        confirm_result = messagebox.askyesno(
            "모델 삭제 확인", 
            f"모델 '{model_name}'을(를) 삭제하시겠습니까?\n\n"
            f"⚠️ 이 작업은 되돌릴 수 없습니다!\n"
            f"모델 파일이 완전히 삭제됩니다."
        )
        
        if not confirm_result:
            logger.info("사용자가 모델 삭제를 취소함")
            log_user_action("모델 삭제", f"취소됨: {model_name}")
            return
        
        def _delete_model():
            """실제 모델 삭제 로직"""
            try:
                # 진행률 초기화
                update_gui_safely(root, lambda: progress_var.set(0))
                update_gui_safely(root, lambda: progress_text_var.set("모델 삭제 중..."))
                
                logger.info(f"Ollama 모델 삭제 시작: {model_name}")
                log_user_action("모델 삭제", f"시작: {model_name}")
                
                # 모델 삭제 실행
                success, message = delete_ollama_model(model_name)
                
                if success:
                    update_gui_safely(root, lambda: progress_var.set(100))
                    update_gui_safely(root, lambda: progress_text_var.set("삭제 완료"))
                    logger.info(f"Ollama 모델 삭제 성공: {model_name}")
                    log_user_action("모델 삭제", f"성공: {model_name}")
                    
                    # 성공 메시지 표시
                    update_gui_safely(root, lambda: messagebox.showinfo("삭제 완료", message))
                    
                    # 모델 목록 새로고침
                    model_list = update_ollama_model_list()
                    update_gui_safely(root, lambda: installed_model_combo.configure(values=model_list))
                    update_gui_safely(root, lambda: installed_model_combo.set("모델을 선택하세요"))
                    
                    # 현재 로드된 모델이 삭제된 모델이면 상태 초기화
                    current_loaded = loaded_model_var.get()
                    if current_loaded == f"Ollama: {model_name}":
                        update_gui_safely(root, lambda: update_model_status("", False))
                    
                    logger.info("모델 목록 새로고침 완료")
                    
                else:
                    update_gui_safely(root, lambda: progress_var.set(0))
                    update_gui_safely(root, lambda: progress_text_var.set("삭제 실패"))
                    logger.error(f"Ollama 모델 삭제 실패: {model_name} - {message}")
                    log_user_action("모델 삭제", f"실패: {model_name} - {message}")
                    update_gui_safely(root, lambda: messagebox.showerror("삭제 실패", f"모델 삭제에 실패했습니다:\n{message}"))
                    
            except Exception as e:
                logger.error(f"모델 삭제 중 예외 발생: {str(e)}")
                update_gui_safely(root, lambda: progress_text_var.set("오류 발생"))
                update_gui_safely(root, lambda: messagebox.showerror("오류", f"모델 삭제 중 오류가 발생했습니다:\n{str(e)}"))
        
        # 별도 스레드에서 실행
        threading.Thread(target=_delete_model, daemon=True).start()

    delete_model_btn = tk.Button(ollama_frame, text="선택된 모델 삭제", command=delete_selected_model,
                                bg="#f44336", fg="white", font=("Arial", 10, "bold"))
    delete_model_btn.pack(side="left", padx=5)

    # 다운로드 버튼 클릭 이벤트
    def on_download():
        """모델 다운로드 버튼 클릭 시 실행되는 함수 (비동기 처리)"""
        logger = logging.getLogger('LlmLoader')
        start_time = time.time()
        
        # 입력값 가져오기
        platform = platform_var.get()
        model_repo = model_entry.get().strip()
        model_filename = model_file_entry.get().strip()
        save_dir = save_dir_entry.get().strip()
        
        log_user_action("모델 다운로드", f"플랫폼: {platform}, 모델: {model_repo}")
        
        # 모델명 자동 수정 (Ollama의 경우)
        if platform == "Ollama":
            original_model = model_repo
            # 'ollama run', 'ollama pull' 등의 명령어 제거
            if model_repo.lower().startswith('ollama '):
                # 명령어 부분 제거하고 모델명만 추출
                parts = model_repo.split()
                if len(parts) >= 3 and parts[0].lower() == 'ollama' and parts[1].lower() in ['run', 'pull']:
                    model_repo = ' '.join(parts[2:])
                    logger.info(f"모델명 자동 수정: '{original_model}' → '{model_repo}'")
                    log_validation_result("모델명 자동 수정", True, f"'{original_model}' → '{model_repo}'")
                    # GUI에도 수정된 모델명 반영
                    model_entry.delete(0, tk.END)
                    model_entry.insert(0, model_repo)
        
        logger.info(f"다운로드 요청: 플랫폼={platform}, 모델={model_repo}, 파일명={model_filename}, 경로={save_dir}")
        
        # 입력값 검증
        if not model_repo:
            logger.warning("모델명이 입력되지 않음")
            log_validation_result("모델명 입력", False, "모델명이 비어있음")
            messagebox.showerror("오류", "모델명을 입력해주세요.")
            return
            
        # 저장 경로 검증 (Ollama는 자동으로 기본 위치 사용)
        if platform == "HuggingFace" and not save_dir:
            logger.warning("저장 경로가 입력되지 않음")
            log_validation_result("저장 경로 입력", False, "저장 경로가 비어있음")
            messagebox.showerror("오류", "저장 경로를 입력해주세요.")
            return
        
        # Ollama 모델명 추가 검증
        if platform == "Ollama":
            if ' ' in model_repo and not model_repo.startswith('ollama/'):
                logger.warning(f"잘못된 Ollama 모델명 형식: {model_repo}")
                log_validation_result("Ollama 모델명 형식", False, f"잘못된 형식: {model_repo}")
                messagebox.showwarning("경고", 
                    f"Ollama 모델명 형식이 올바르지 않습니다.\n"
                    f"입력: {model_repo}\n"
                    f"예시: gemma3, llama3, mistral, codellama 등")
                return
        
        def _download_model():
            """실제 모델 다운로드 로직"""
            try:
                # 저장 디렉토리 생성 (HuggingFace만)
                if platform == "HuggingFace" and not os.path.exists(save_dir):
                    os.makedirs(save_dir)
                    logger.info(f"저장 디렉토리 생성: {save_dir}")
                
                # 진행률 초기화
                update_gui_safely(root, lambda: progress_var.set(0))
                update_gui_safely(root, lambda: progress_text_var.set("다운로드 준비 중..."))
                
                # 플랫폼별 다운로드 실행
                if platform == "HuggingFace":
                    logger.info("HuggingFace 다운로드 시작")
                    log_model_operation("다운로드 시작", model_repo, "HuggingFace", f"파일명: {model_filename}")
                    
                    file_path, err = download_model_huggingface(model_repo, model_filename, save_dir, update_progress)
                    if file_path:
                        update_gui_safely(root, lambda: progress_var.set(100))
                        update_gui_safely(root, lambda: progress_text_var.set("다운로드 완료"))
                        logger.info("HuggingFace 다운로드 성공")
                        log_user_action("HuggingFace 다운로드", "성공")
                    else:
                        update_gui_safely(root, lambda: progress_text_var.set("다운로드 실패"))
                        logger.error(f"HuggingFace 다운로드 실패: {err}")
                        log_user_action("HuggingFace 다운로드", f"실패: {err}")
                        
                elif platform == "Ollama":
                    logger.info("Ollama 다운로드 시작")
                    log_model_operation("다운로드 시작", model_repo, "Ollama")
                    
                    # Ollama는 저장 경로를 무시하고 기본 위치 사용
                    msg, err = download_model_ollama(model_repo, None, update_progress)
                    if msg:
                        update_gui_safely(root, lambda: progress_var.set(100))
                        update_gui_safely(root, lambda: progress_text_var.set("다운로드 완료"))
                        logger.info("Ollama 다운로드 성공")
                        log_user_action("Ollama 다운로드", "성공")
                    else:
                        update_gui_safely(root, lambda: progress_text_var.set("다운로드 실패"))
                        logger.error(f"Ollama 다운로드 실패: {err}")
                        log_user_action("Ollama 다운로드", f"실패: {err}")
                else:
                    logger.error(f"지원하지 않는 플랫폼: {platform}")
                    log_validation_result("플랫폼 지원", False, f"지원하지 않는 플랫폼: {platform}")
                    
            except Exception as e:
                logger.error(f"다운로드 중 예외 발생: {str(e)}")
                update_gui_safely(root, lambda: progress_text_var.set("오류 발생"))
                update_gui_safely(root, lambda: messagebox.showerror("오류", f"다운로드 중 오류가 발생했습니다:\n{str(e)}"))
        
        # 별도 스레드에서 실행
        threading.Thread(target=_download_model, daemon=True).start()

    # 다운로드 버튼을 on_download 함수 정의 이후에 생성
    download_btn = tk.Button(ollama_frame, text="모델 다운로드", command=on_download, 
                            bg="#2196F3", fg="white", font=("Arial", 10, "bold"))
    download_btn.pack(side="left", padx=5)

    # 선택된 모델 로딩 및 테스트 버튼
    def load_selected_model():
        """선택된 모델을 로딩하고 테스트하는 함수 (비동기 처리)"""
        logger = logging.getLogger('LlmLoader')
        
        # 입력값 가져오기
        platform = platform_var.get()
        selected_model = installed_model_var.get()
        model_repo = model_entry.get().strip()
        
        logger.info(f"모델 로딩 요청: 플랫폼={platform}, 선택된 모델={selected_model}, 입력 모델={model_repo}")
        
        # 모델 선택 확인
        if selected_model == "모델을 선택하세요" or not selected_model:
            logger.warning("모델이 선택되지 않음")
            messagebox.showwarning("경고", "설치된 모델 목록에서 테스트할 모델을 선택해주세요.")
            return
        
        # 모델명 추출 (크기 정보 제거)
        model_name = selected_model.split(' (')[0]
        
        def _load_and_test_model():
            """실제 모델 로딩 및 테스트 로직"""
            try:
                # 진행률 초기화
                update_gui_safely(root, lambda: progress_var.set(0))
                update_gui_safely(root, lambda: progress_text_var.set("모델 로딩 중..."))
                
                if platform == "Ollama":
                    logger.info(f"Ollama 모델 로딩 시작: {model_name}")
                    
                    # 모델 로딩
                    success, message = load_ollama_model(model_name)
                    if success:
                        update_gui_safely(root, lambda: progress_var.set(50))
                        update_gui_safely(root, lambda: progress_text_var.set("모델 테스트 중..."))
                        
                        # 간단한 테스트 프롬프트로 모델 테스트
                        test_prompt = "안녕하세요! 간단한 테스트입니다. 한 문장으로 답변해주세요."
                        test_success, test_result = test_ollama_model(model_name, test_prompt, update_progress)
                        
                        if test_success:
                            update_gui_safely(root, lambda: progress_var.set(100))
                            update_gui_safely(root, lambda: progress_text_var.set("테스트 완료"))
                            logger.info(f"Ollama 모델 응답 완료: {model_name}")
                            logger.info(f"응답 내용: {test_result}")  # 응답 내용을 로그에 기록
                            update_gui_safely(root, lambda: update_result_and_answer(f"질문: {test_prompt}\n\n답변:\n{test_result}"))
                            # 현재 로드된 모델 표시 업데이트
                            update_gui_safely(root, lambda: update_model_status(f"{platform}: {model_name}", True))
                            log_user_action("모델 로딩 완료", f"플랫폼: {platform}, 모델: {model_name}")
                            logger.info("Ollama 모델 로딩 및 테스트 성공")
                        else:
                            update_gui_safely(root, lambda: progress_text_var.set("테스트 실패"))
                            update_gui_safely(root, lambda: update_model_status("없음", False))
                            logger.warning(f"Ollama 모델 테스트 실패: {test_result}")
                    else:
                        update_gui_safely(root, lambda: progress_text_var.set("로딩 실패"))
                        update_gui_safely(root, lambda: update_model_status("없음", False))
                        logger.error(f"Ollama 모델 로딩 실패: {message}")
                        
                elif platform == "HuggingFace":
                    logger.info(f"HuggingFace 모델 로딩 시작: {model_repo}")
                    
                    # HuggingFace 모델 경로 확인
                    model_path = os.path.join(save_dir_entry.get().strip(), model_file_entry.get().strip())
                    if not os.path.exists(model_path):
                        update_gui_safely(root, lambda: progress_text_var.set("모델 파일 없음"))
                        update_gui_safely(root, lambda: update_model_status("없음", False))
                        logger.error(f"HuggingFace 모델 파일 없음: {model_path}")
                        return
                    
                    # 모델 로딩
                    success, message = load_huggingface_model(model_path)
                    if success:
                        update_gui_safely(root, lambda: progress_var.set(50))
                        update_gui_safely(root, lambda: progress_text_var.set("모델 테스트 중..."))
                        
                        # 간단한 테스트 프롬프트로 모델 테스트
                        test_prompt = "안녕하세요! 간단한 테스트입니다. 한 문장으로 답변해주세요."
                        test_success, test_result = test_huggingface_model(model_path, test_prompt, update_progress)
                        
                        if test_success:
                            update_gui_safely(root, lambda: progress_var.set(100))
                            update_gui_safely(root, lambda: progress_text_var.set("테스트 완료"))
                            # 현재 로드된 모델 표시 업데이트
                            update_gui_safely(root, lambda: update_model_status(f"{platform}: {model_repo}", True))
                            log_user_action("모델 로딩 완료", f"플랫폼: {platform}, 모델: {model_repo}")
                            logger.info("HuggingFace 모델 로딩 및 테스트 성공")
                        else:
                            update_gui_safely(root, lambda: progress_text_var.set("테스트 실패"))
                            update_gui_safely(root, lambda: update_model_status("없음", False))
                            logger.warning(f"HuggingFace 모델 테스트 실패: {test_result}")
                    else:
                        update_gui_safely(root, lambda: progress_text_var.set("로딩 실패"))
                        update_gui_safely(root, lambda: update_model_status("없음", False))
                        logger.error(f"HuggingFace 모델 로딩 실패: {message}")
                else:
                    logger.error(f"지원하지 않는 플랫폼: {platform}")
                    update_gui_safely(root, lambda: progress_text_var.set("지원하지 않는 플랫폼"))
                    update_gui_safely(root, lambda: update_model_status("없음", False))
                    
            except Exception as e:
                logger.error(f"모델 로딩 중 예외 발생: {str(e)}")
                update_gui_safely(root, lambda: progress_text_var.set("오류 발생"))
                update_gui_safely(root, lambda: update_model_status("없음", False))
        
        # 별도 스레드에서 실행
        threading.Thread(target=_load_and_test_model, daemon=True).start()

    # 모델 로딩 버튼 프레임
    load_model_frame = tk.Frame(root)
    load_model_frame.pack(fill="x", padx=10, pady=5)
    
    load_model_btn = tk.Button(load_model_frame, text="선택된 모델 로딩 및 테스트", 
                              command=load_selected_model, bg="#4CAF50", fg="white", font=("Arial", 10, "bold"))
    load_model_btn.pack(fill="x", pady=5)

    # 모델 로딩 상태 표시
    model_status_frame = tk.Frame(root)
    model_status_frame.pack(fill="x", padx=10, pady=5)
    
    tk.Label(model_status_frame, text="현재 로드된 모델:", font=("Arial", 10, "bold")).pack(anchor="w")
    loaded_model_var = tk.StringVar()
    loaded_model_var.set("없음")
    loaded_model_label = tk.Label(model_status_frame, textvariable=loaded_model_var, 
                                 fg="red", font=("Arial", 10, "bold"), 
                                 bg="#fff0f0", relief="solid", bd=1, padx=5, pady=3)
    loaded_model_label.pack(anchor="w", pady=2, fill="x")
    
    # 모델 상태 업데이트 함수
    def update_model_status(model_info, is_loaded=True):
        """현재 로드된 모델 상태를 업데이트"""
        if is_loaded and model_info:
            loaded_model_var.set(model_info)
            loaded_model_label.config(fg="green", bg="#f0f8f0")
            log_gui_event("모델 상태 업데이트", "loaded_model_label", f"로드됨: {model_info}")
        else:
            loaded_model_var.set("없음")
            loaded_model_label.config(fg="red", bg="#fff0f0")
            log_gui_event("모델 상태 업데이트", "loaded_model_label", "로드되지 않음")
    
    # 진행률 표시 프레임
    progress_frame = tk.Frame(root)
    progress_frame.pack(fill="x", padx=10, pady=5)
    
    # 진행률 바
    progress_var = tk.DoubleVar()
    progress_bar = ttk.Progressbar(progress_frame, variable=progress_var, maximum=100)
    progress_bar.pack(fill="x", pady=2)
    
    # 진행률 텍스트
    progress_text_var = tk.StringVar()
    progress_text_var.set("")
    progress_text_label = tk.Label(progress_frame, textvariable=progress_text_var, fg="blue")
    progress_text_label.pack(anchor="w", pady=2)
    
    # 진행률 업데이트 콜백 함수
    def update_progress(progress, text):
        """진행률과 텍스트를 업데이트 (안전한 GUI 업데이트)"""
        def _update():
            try:
                progress_var.set(progress)
                progress_text_var.set(text)
                root.update_idletasks()  # GUI 업데이트
            except Exception as e:
                logger = logging.getLogger('LlmLoader')
                logger.error(f"진행률 업데이트 중 오류: {str(e)}")
        
        # 메인 스레드에서 안전하게 실행
        update_gui_safely(root, _update)

    # 질문 입력 및 답변 표시 영역
    chat_frame = tk.Frame(root)
    chat_frame.pack(fill="both", expand=True, padx=10, pady=10)
    
    # 질문 입력 영역
    tk.Label(chat_frame, text="질문 입력:", font=("Arial", 10, "bold")).pack(anchor="w", pady=5)
    question_frame = tk.Frame(chat_frame)
    question_frame.pack(fill="x", pady=5)
    
    question_entry = tk.Entry(question_frame)
    question_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))
    question_entry.insert(0, "안녕하세요! 간단한 질문을 해보세요.")
    
    # 답변 표시 영역
    tk.Label(chat_frame, text="답변:", font=("Arial", 10, "bold")).pack(anchor="w", pady=5)
    answer_text = scrolledtext.ScrolledText(chat_frame, height=8, wrap=tk.WORD)
    answer_text.pack(fill="both", expand=True, pady=5)
    answer_text.insert(tk.END, "모델을 선택하고 질문을 입력한 후 '질문 전송' 버튼을 클릭하세요.")
    
    # 답변 텍스트 업데이트 함수
    def update_answer_text(text):
        """답변 텍스트 영역을 업데이트"""
        answer_text.delete(1.0, tk.END)
        answer_text.insert(tk.END, text)
    
    # result_label과 answer_text 동기화를 위한 함수
    def update_result_and_answer(text):
        """답변 텍스트를 업데이트"""
        update_answer_text(text)
    
    # send_question 함수에서 result_label.config 대신 update_result_and_answer 사용
    def send_question():
        """질문 전송 버튼 클릭 시 실행되는 함수 (비동기 처리)"""
        logger = logging.getLogger('LlmLoader')
        start_time = time.time()
        
        # 입력값 가져오기
        platform = platform_var.get()
        selected_model = installed_model_var.get()
        question = question_entry.get().strip()
        
        log_user_action("질문 전송", f"플랫폼: {platform}, 모델: {selected_model}, 질문: {question[:50]}...")
        
        logger.info(f"질문 전송 요청: 플랫폼={platform}, 선택된 모델={selected_model}, 질문={question}")
        
        # 질문 입력 확인
        if not question:
            logger.warning("질문이 입력되지 않음")
            log_validation_result("질문 입력", False, "질문이 비어있음")
            messagebox.showwarning("경고", "질문을 입력해주세요.")
            return
        
        # 모델 선택 확인
        if selected_model == "모델을 선택하세요" or not selected_model:
            logger.warning("모델이 선택되지 않음")
            log_validation_result("모델 선택", False, "모델이 선택되지 않음")
            messagebox.showwarning("경고", "설치된 모델 목록에서 사용할 모델을 선택해주세요.")
            return
        
        # 모델명 추출 (크기 정보 제거)
        model_name = selected_model.split(' (')[0]
        
        def _process_question():
            """실제 질문 처리 로직"""
            try:
                # 진행률 초기화
                update_gui_safely(root, lambda: progress_var.set(0))
                update_gui_safely(root, lambda: progress_text_var.set("질문 처리 중..."))
                update_gui_safely(root, lambda: update_result_and_answer("질문 처리 중..."))
                
                if platform == "Ollama":
                    logger.info(f"Ollama 모델 질문 처리 시작: {model_name}")
                    log_model_operation("질문 처리 시작", model_name, "Ollama", f"질문: {question[:50]}...")
                    
                    # 모델 테스트
                    update_gui_safely(root, lambda: progress_var.set(50))
                    update_gui_safely(root, lambda: progress_text_var.set("모델 응답 생성 중..."))
                    
                    test_result, err = test_ollama_model(model_name, question, update_progress)
                    
                    if test_result:
                        update_gui_safely(root, lambda: progress_var.set(100))
                        update_gui_safely(root, lambda: progress_text_var.set("응답 완료"))
                        logger.info(f"Ollama 모델 응답 완료: {model_name}")
                        logger.info(f"응답 내용: {test_result}")  # 응답 내용을 로그에 기록
                        update_gui_safely(root, lambda: update_result_and_answer(f"질문: {question}\n\n답변:\n{test_result}"))
                        # 현재 로드된 모델 표시 업데이트
                        update_gui_safely(root, lambda: update_model_status(f"{platform}: {model_name}", True))
                        log_user_action("Ollama 질문 처리", "성공")
                    else:
                        update_gui_safely(root, lambda: progress_text_var.set("응답 실패"))
                        update_gui_safely(root, lambda: update_result_and_answer(f"질문 처리 실패: {err}"))
                        log_user_action("Ollama 질문 처리", f"실패: {err}")
                        
                elif platform == "HuggingFace":
                    logger.info(f"HuggingFace 모델 질문 처리 시작: {model_name}")
                    log_model_operation("질문 처리 시작", model_name, "HuggingFace", f"질문: {question[:50]}...")
                    
                    # 모델 파일 경로 구성 (models 폴더 기준)
                    model_path = os.path.join("models", model_name)
                    
                    # 모델 테스트
                    update_gui_safely(root, lambda: progress_var.set(50))
                    update_gui_safely(root, lambda: progress_text_var.set("모델 응답 생성 중..."))
                    
                    test_result, err = test_huggingface_model(model_path, question, update_progress)
                    
                    if test_result:
                        update_gui_safely(root, lambda: progress_var.set(100))
                        update_gui_safely(root, lambda: progress_text_var.set("응답 완료"))
                        update_gui_safely(root, lambda: update_result_and_answer(f"질문: {question}\n\n답변:\n{test_result}"))
                        # 현재 로드된 모델 표시 업데이트
                        update_gui_safely(root, lambda: update_model_status(f"{platform}: {model_name}", True))
                        log_user_action("HuggingFace 질문 처리", "성공")
                    else:
                        update_gui_safely(root, lambda: progress_text_var.set("응답 실패"))
                        update_gui_safely(root, lambda: update_result_and_answer(f"질문 처리 실패: {err}"))
                        log_user_action("HuggingFace 질문 처리", f"실패: {err}")
                else:
                    update_gui_safely(root, lambda: progress_text_var.set("지원하지 않는 플랫폼"))
                    update_gui_safely(root, lambda: update_result_and_answer(f"지원하지 않는 플랫폼: {platform}"))
                    logger.error(f"지원하지 않는 플랫폼: {platform}")
                
                execution_time = time.time() - start_time
                log_performance_metric("질문 처리", execution_time, f"플랫폼: {platform}, 모델: {model_name}")
                    
            except Exception as e:
                logger.error(f"질문 처리 중 예외 발생: {str(e)}")
                update_gui_safely(root, lambda: progress_text_var.set("오류 발생"))
                update_gui_safely(root, lambda: update_result_and_answer(f"질문 처리 중 오류가 발생했습니다:\n{str(e)}"))
        
        # 별도 스레드에서 실행
        threading.Thread(target=_process_question, daemon=True).start()
    
    send_btn = tk.Button(question_frame, text="질문 전송", command=send_question, 
                        bg="#FF9800", fg="white", font=("Arial", 9, "bold"))
    send_btn.pack(side="right")
    
    # Enter 키로도 질문 전송 가능
    def on_enter(event):
        send_question()
    
    question_entry.bind('<Return>', on_enter)

    logger.info("GUI 구성 완료, 메인 루프 시작")
    root.mainloop()
    logger.info("LLM Loader 애플리케이션 종료")

# Ollama 모델 삭제 함수
@log_exception_handler
def delete_ollama_model(model_name):
    """Ollama 모델을 삭제하고 로그를 기록 (비동기 처리)"""
    logger = logging.getLogger('LlmLoader')
    start_time = time.time()
    
    log_model_operation("삭제 시작", model_name, "Ollama")
    log_user_action("Ollama 모델 삭제", f"모델: {model_name}")
    
    def _delete_model():
        """실제 모델 삭제 로직"""
        try:
            # ollama rm 명령어 실행
            command = ["ollama", "rm", model_name]
            logger.debug(f"실행할 명령어: {' '.join(command)}")
            
            # 타임아웃 설정 (30초)
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            execution_time = time.time() - start_time
            
            if result.returncode == 0:
                logger.info(f"Ollama 모델 삭제 성공: {model_name}")
                log_model_operation("삭제 완료", model_name, "Ollama")
                log_performance_metric("Ollama 모델 삭제", execution_time)
                return True, f"모델 '{model_name}'이(가) 성공적으로 삭제되었습니다."
            else:
                error_msg = result.stderr.strip() if result.stderr else "알 수 없는 오류"
                logger.error(f"Ollama 모델 삭제 실패: {model_name} - {error_msg}")
                log_model_operation("삭제 실패", model_name, "Ollama", error_msg)
                return False, f"모델 삭제 실패: {error_msg}"
                
        except subprocess.TimeoutExpired:
            execution_time = time.time() - start_time
            logger.error(f"Ollama 모델 삭제 시간 초과: {model_name}")
            log_model_operation("삭제 실패", model_name, "Ollama", "시간 초과")
            log_performance_metric("Ollama 모델 삭제 (시간 초과)", execution_time)
            return False, "모델 삭제가 시간 초과되었습니다."
            
        except FileNotFoundError:
            execution_time = time.time() - start_time
            logger.error(f"ollama 명령어를 찾을 수 없음: {model_name}")
            log_model_operation("삭제 실패", model_name, "Ollama", "ollama 명령어 없음")
            log_performance_metric("Ollama 모델 삭제 (명령어 없음)", execution_time)
            return False, "ollama 명령어를 찾을 수 없습니다. Ollama가 설치되어 있는지 확인해주세요."
            
        except Exception as e:
            execution_time = time.time() - start_time
            log_error_with_traceback(e, f"Ollama 모델 삭제 중 - {model_name}")
            log_model_operation("삭제 실패", model_name, "Ollama", f"오류: {str(e)}")
            log_performance_metric("Ollama 모델 삭제 (실패)", execution_time)
            return False, f"모델 삭제 중 오류가 발생했습니다: {str(e)}"
    
    # 별도 스레드에서 실행
    return run_in_thread(_delete_model)

if __name__ == "__main__":
    main() 